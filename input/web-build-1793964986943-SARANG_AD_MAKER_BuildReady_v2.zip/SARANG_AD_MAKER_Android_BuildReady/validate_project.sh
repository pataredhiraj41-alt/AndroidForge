#!/usr/bin/env sh
set -eu
[ -f pubspec.yaml ] || { echo 'Missing root pubspec.yaml'; exit 1; }
[ -f lib/main.dart ] || { echo 'Missing lib/main.dart'; exit 1; }
[ -f android/app/build.gradle ] || { echo 'Missing Android app Gradle config'; exit 1; }
[ -f android/app/src/main/AndroidManifest.xml ] || { echo 'Missing AndroidManifest.xml'; exit 1; }
echo 'Project structure checks passed.'
