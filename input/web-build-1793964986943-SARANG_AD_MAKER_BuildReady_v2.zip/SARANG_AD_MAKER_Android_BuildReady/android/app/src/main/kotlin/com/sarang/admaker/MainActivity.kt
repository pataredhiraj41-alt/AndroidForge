package com.sarang.admaker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
