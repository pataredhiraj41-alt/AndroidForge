import base64
import io
import os
import uuid
from pathlib import Path
from typing import Optional

import httpx
from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pydantic_settings import BaseSettings
from sqlalchemy import create_engine, String, Text, Integer, DateTime, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker
from PIL import Image, ImageDraw, ImageFont, ImageFilter


class Settings(BaseSettings):
    openai_api_key: str = ""
    openai_image_model: str = "gpt-image-1"
    database_url: str = "sqlite:///./sarang.db"
    public_base_url: str = "http://localhost:8000"
    upload_dir: str = "storage/uploads"
    output_dir: str = "storage/outputs"

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
Path(settings.upload_dir).mkdir(parents=True, exist_ok=True)
Path(settings.output_dir).mkdir(parents=True, exist_ok=True)

connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}
engine = create_engine(settings.database_url, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)


class Base(DeclarativeBase):
    pass


class Product(Base):
    __tablename__ = "products"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(180))
    category: Mapped[str] = mapped_column(String(120))
    brand: Mapped[str] = mapped_column(String(120), default="")
    size_variant: Mapped[str] = mapped_column(String(120), default="")
    tagline_mr: Mapped[str] = mapped_column(String(250), default="")
    photo_path: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[str] = mapped_column(DateTime, server_default=func.now())


class Advertisement(Base):
    __tablename__ = "advertisements"
    id: Mapped[int] = mapped_column(Integer, primary_key=True, index=True)
    product_id: Mapped[int] = mapped_column(Integer)
    poster_path: Mapped[str] = mapped_column(String(500))
    gif_path: Mapped[str] = mapped_column(String(500))
    status: Mapped[str] = mapped_column(String(40), default="completed")
    created_at: Mapped[str] = mapped_column(DateTime, server_default=func.now())


Base.metadata.create_all(bind=engine)

app = FastAPI(title="SARANG AD MAKER API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Lock this down to your app/domain before production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.mount("/media", StaticFiles(directory="storage"), name="media")


@app.get("/health")
def health():
    return {"status": "ok", "app": "SARANG AD MAKER"}


@app.get("/api/categories")
def categories():
    return {"categories": [
        "हार्डवेअर व फास्टनर्स", "हँड टूल्स व पॉवर टूल्स", "सेफ्टी साहित्य",
        "इलेक्ट्रिकल साहित्य", "फॅब्रिकेशन व वेल्डिंग", "पाईप्स व प्लंबिंग",
        "स्टेशनरी", "क्लिनिंग व हाऊसकीपिंग", "जनरल प्लास्टिक",
        "जार, बाटल्या व कंटेनर्स", "कन्स्ट्रक्शन मटेरियल", "अॅडहेसिव्ह, टेप व सीलंट",
        "इंडस्ट्रियल सप्लाइज", "इतर उत्पादने"
    ]}


@app.post("/api/products")
async def create_product(
    name: str = Form(...),
    category: str = Form(...),
    brand: str = Form(""),
    size_variant: str = Form(""),
    tagline_mr: str = Form(""),
    photo: UploadFile = File(...)
):
    if not photo.content_type or not photo.content_type.startswith("image/"):
        raise HTTPException(400, "कृपया JPG किंवा PNG फोटो अपलोड करा.")
    content = await photo.read()
    if len(content) > 15 * 1024 * 1024:
        raise HTTPException(413, "फोटो 15 MB पेक्षा लहान असावा.")
    ext = Path(photo.filename or "product.jpg").suffix.lower()
    if ext not in [".jpg", ".jpeg", ".png", ".webp"]:
        ext = ".jpg"
    filename = f"{uuid.uuid4().hex}{ext}"
    path = str(Path(settings.upload_dir) / filename)
    Path(path).write_bytes(content)

    db = SessionLocal()
    try:
        product = Product(
            name=name.strip(), category=category.strip(), brand=brand.strip(),
            size_variant=size_variant.strip(), tagline_mr=tagline_mr.strip(),
            photo_path=path
        )
        db.add(product)
        db.commit()
        db.refresh(product)
        return {
            "id": product.id, "name": product.name, "category": product.category,
            "photo_url": f"{settings.public_base_url}/media/uploads/{filename}"
        }
    finally:
        db.close()


def find_font(size: int, bold: bool = False):
    candidates = [
        "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Bold.ttf" if bold else "/usr/share/fonts/truetype/noto/NotoSansDevanagari-Regular.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for p in candidates:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def add_shop_footer(image: Image.Image) -> Image.Image:
    image = image.convert("RGB")
    w, h = image.size
    footer_h = max(190, int(h * 0.19))
    footer = Image.new("RGB", (w, h + footer_h), (7, 18, 39))
    footer.paste(image, (0, 0))
    d = ImageDraw.Draw(footer)
    d.rectangle((0, h, w, h + 8), fill=(245, 183, 50))
    margin = int(w * 0.045)
    d.text((margin, h + 22), "SARANG ENTERPRISES", font=find_font(max(25, int(w*0.045)), True), fill="white")
    d.text((margin, h + 65), "हार्डवेअर अँड जनरल ट्रेडर्स", font=find_font(max(19, int(w*0.031)), True), fill=(255, 210, 90))
    d.text((margin, h + 105), "गाळा क्र. 20, MIDC Centre Complex,", font=find_font(max(16, int(w*0.026))), fill="white")
    d.text((margin, h + 135), "Shingve Tukai, Ahmednagar", font=find_font(max(16, int(w*0.026))), fill="white")
    d.rounded_rectangle((int(w*.61), h+93, w-margin, h+footer_h-18), radius=18, fill=(156, 24, 32), outline=(255, 205, 70), width=3)
    d.text((int(w*.64), h+105), "कॉल / व्हॉट्सअॅप", font=find_font(max(14, int(w*.022)), True), fill=(255, 225, 150))
    d.text((int(w*.635), h+137), "7038080722", font=find_font(max(22, int(w*.038)), True), fill="white")
    return footer


def make_animated_gif(poster_path: str, gif_path: str):
    poster = Image.open(poster_path).convert("RGB")
    poster.thumbnail((720, 1280), Image.Resampling.LANCZOS)
    w, h = poster.size
    frames = []
    for i in range(16):
        t = i / 16
        zoom = 1.0 + 0.018 * (0.5 - 0.5 * __import__("math").cos(2 * __import__("math").pi * t))
        nw, nh = int(w*zoom), int(h*zoom)
        scaled = poster.resize((nw, nh), Image.Resampling.LANCZOS)
        x, y = (nw-w)//2, (nh-h)//2
        frame = scaled.crop((x, y, x+w, y+h)).convert("RGBA")
        glow = Image.new("RGBA", (w,h), (0,0,0,0))
        gd = ImageDraw.Draw(glow)
        pulse = 0.5 + 0.5*__import__("math").sin(2*__import__("math").pi*t)
        gd.rounded_rectangle((int(w*.60), int(h*.84), w-8, h-8), radius=20,
                             outline=(255,205,70,int(45+100*pulse)), width=5)
        glow = glow.filter(ImageFilter.GaussianBlur(7))
        frame = Image.alpha_composite(frame, glow)
        frames.append(frame.convert("P", palette=Image.Palette.ADAPTIVE, colors=128))
    frames[0].save(gif_path, save_all=True, append_images=frames[1:],
                   duration=120, loop=0, optimize=True, disposal=2)


@app.post("/api/ads/generate")
async def generate_ad(
    product_id: int = Form(...),
    output: str = Form("poster_and_gif")
):
    if not settings.openai_api_key:
        raise HTTPException(503, "Backend .env मध्ये OPENAI_API_KEY सेट करा.")
    db = SessionLocal()
    try:
        product = db.get(Product, product_id)
        if not product:
            raise HTTPException(404, "प्रॉडक्ट सापडले नाही.")
        photo_bytes = Path(product.photo_path).read_bytes()
        prompt = f"""
Create a premium vertical 9:16 Marathi-only commercial advertisement for SARANG ENTERPRISES.
Use the uploaded product photograph as the primary visual reference. Preserve the real product identity,
shape, colour, packaging and visible brand as closely as possible. Do not invent product specifications,
discounts, prices or stock claims. Make a cinematic premium 3D industrial retail scene with elegant
navy blue, black, silver and gold lighting. Product name: {product.name}.
Category: {product.category}. Brand: {product.brand or 'not specified'}.
Size: {product.size_variant or 'not specified'}.
Marathi tagline: {product.tagline_mr or 'औद्योगिक, व्यावसायिक आणि घरगुती गरजांसाठी विश्वासार्ह ठिकाण'}.
Leave a clean lower footer area for accurate shop details to be added by the app.
Avoid generating phone numbers or addresses inside the image. Use Marathi-only promotional copy.
"""
        headers = {"Authorization": f"Bearer {settings.openai_api_key}"}
        files = {"image": (Path(product.photo_path).name, photo_bytes, "image/jpeg")}
        data = {
            "model": settings.openai_image_model,
            "prompt": prompt,
            "size": "1024x1536",
            "quality": "high",
            "output_format": "png"
        }
        async with httpx.AsyncClient(timeout=180) as client:
            response = await client.post(
                "https://api.openai.com/v1/images/edits",
                headers=headers, data=data, files=files
            )
        if response.status_code >= 400:
            raise HTTPException(502, f"AI image service error: {response.text[:700]}")
        payload = response.json()
        b64 = payload.get("data", [{}])[0].get("b64_json")
        if not b64:
            raise HTTPException(502, "AI कडून image result मिळाला नाही.")
        raw = base64.b64decode(b64)
        ai_image = Image.open(io.BytesIO(raw))
        final_image = add_shop_footer(ai_image)
        ad_id = uuid.uuid4().hex
        poster_name = f"{ad_id}.png"
        gif_name = f"{ad_id}.gif"
        poster_path = str(Path(settings.output_dir) / poster_name)
        gif_path = str(Path(settings.output_dir) / gif_name)
        final_image.save(poster_path, "PNG")
        make_animated_gif(poster_path, gif_path)

        ad = Advertisement(product_id=product.id, poster_path=poster_path, gif_path=gif_path)
        db.add(ad)
        db.commit()
        return {
            "advertisement_id": ad.id,
            "poster_url": f"{settings.public_base_url}/media/outputs/{poster_name}",
            "gif_url": f"{settings.public_base_url}/media/outputs/{gif_name}",
            "message_mr": "तुमची जाहिरात तयार झाली आहे."
        }
    finally:
        db.close()
