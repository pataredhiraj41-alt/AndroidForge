class AppConfig {
  // Android Emulator: 10.0.2.2 points to the development computer.
  // Physical phone: replace with your computer's LAN IP, e.g. http://192.168.1.10:8000
  static const String apiBaseUrl = 'http://10.0.2.2:8000';
  static const String shopName = 'SARANG ENTERPRISES';
  static const String shopPhone = '7038080722';
  static const String shopAddress =
      'Gala No. 20, MIDC Centre Complex, Shingve Tukai, Ahmednagar';
}
