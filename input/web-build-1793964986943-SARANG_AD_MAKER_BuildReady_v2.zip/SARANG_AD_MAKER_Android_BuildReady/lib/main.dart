import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import 'config.dart';

void main() => runApp(const SarangAdMakerApp());

class SarangAdMakerApp extends StatelessWidget {
  const SarangAdMakerApp({super.key});

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF101D36);
    const gold = Color(0xFFF2BD4B);
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'SARANG AD MAKER',
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: gold, brightness: Brightness.light),
        scaffoldBackgroundColor: const Color(0xFFF5F6F8),
        appBarTheme: const AppBarTheme(backgroundColor: navy, foregroundColor: Colors.white),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: navy, foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 15),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
        ),
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final picker = ImagePicker();
  final nameController = TextEditingController();
  final brandController = TextEditingController();
  final sizeController = TextEditingController();
  final taglineController = TextEditingController(text: 'औद्योगिक, व्यावसायिक आणि घरगुती गरजांसाठी विश्वासार्ह ठिकाण!');
  final categories = const [
    'हार्डवेअर व फास्टनर्स', 'हँड टूल्स व पॉवर टूल्स', 'सेफ्टी साहित्य',
    'इलेक्ट्रिकल साहित्य', 'फॅब्रिकेशन व वेल्डिंग', 'पाईप्स व प्लंबिंग',
    'स्टेशनरी', 'क्लिनिंग व हाऊसकीपिंग', 'जनरल प्लास्टिक',
    'जार, बाटल्या व कंटेनर्स', 'कन्स्ट्रक्शन मटेरियल',
    'अॅडहेसिव्ह, टेप व सीलंट', 'इंडस्ट्रियल सप्लाइज', 'इतर उत्पादने'
  ];

  XFile? photo;
  String category = 'हार्डवेअर व फास्टनर्स';
  bool busy = false;
  String? posterUrl;
  String? gifUrl;
  String? error;

  Future<void> choosePhoto(ImageSource source) async {
    final selected = await picker.pickImage(source: source, imageQuality: 92, maxWidth: 1800);
    if (selected != null) {
      setState(() {
        photo = selected;
        posterUrl = null;
        gifUrl = null;
        error = null;
      });
    }
  }

  Future<void> createAdvertisement() async {
    if (photo == null || nameController.text.trim().isEmpty) {
      setState(() => error = 'कृपया प्रॉडक्टचा फोटो आणि नाव भरा.');
      return;
    }
    setState(() { busy = true; error = null; posterUrl = null; gifUrl = null; });
    try {
      final uploadUri = Uri.parse('${AppConfig.apiBaseUrl}/api/products');
      final upload = http.MultipartRequest('POST', uploadUri)
        ..fields['name'] = nameController.text.trim()
        ..fields['category'] = category
        ..fields['brand'] = brandController.text.trim()
        ..fields['size_variant'] = sizeController.text.trim()
        ..fields['tagline_mr'] = taglineController.text.trim()
        ..files.add(await http.MultipartFile.fromPath('photo', photo!.path));
      final uploadResponse = await upload.send().timeout(const Duration(seconds: 90));
      final uploadBody = await uploadResponse.stream.bytesToString();
      if (uploadResponse.statusCode < 200 || uploadResponse.statusCode >= 300) {
        throw Exception(_messageFrom(uploadBody));
      }
      final product = jsonDecode(uploadBody) as Map<String, dynamic>;
      final adUri = Uri.parse('${AppConfig.apiBaseUrl}/api/ads/generate');
      final adRequest = http.MultipartRequest('POST', adUri)
        ..fields['product_id'] = product['id'].toString()
        ..fields['output'] = 'poster_and_gif';
      final adResponse = await adRequest.send().timeout(const Duration(minutes: 4));
      final adBody = await adResponse.stream.bytesToString();
      if (adResponse.statusCode < 200 || adResponse.statusCode >= 300) {
        throw Exception(_messageFrom(adBody));
      }
      final result = jsonDecode(adBody) as Map<String, dynamic>;
      setState(() {
        posterUrl = result['poster_url'] as String?;
        gifUrl = result['gif_url'] as String?;
      });
    } catch (e) {
      setState(() => error = 'जाहिरात तयार करताना अडचण आली: $e');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  String _messageFrom(String body) {
    try {
      final value = jsonDecode(body);
      return (value['detail'] ?? body).toString();
    } catch (_) {
      return body;
    }
  }

  Future<void> shareUrl(String? url, String label) async {
    if (url == null) return;
    try {
      final response = await http.get(Uri.parse(url)).timeout(const Duration(minutes: 2));
      if (response.statusCode != 200) throw Exception('File डाउनलोड झाला नाही.');
      final dir = await getTemporaryDirectory();
      final ext = label.toLowerCase().contains('gif') ? 'gif' : 'png';
      final file = File('${dir.path}/sarang_ad.$ext');
      await file.writeAsBytes(response.bodyBytes);
      await Share.shareXFiles([XFile(file.path)], text: 'SARANG ENTERPRISES – ${AppConfig.shopPhone}');
    } catch (e) {
      setState(() => error = 'Share करताना अडचण: $e');
    }
  }

  @override
  void dispose() {
    nameController.dispose();
    brandController.dispose();
    sizeController.dispose();
    taglineController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    const navy = Color(0xFF101D36);
    const gold = Color(0xFFF2BD4B);
    return Scaffold(
      appBar: AppBar(
        title: const Text('SARANG AD MAKER', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [IconButton(onPressed: () => showAboutDialog(context: context, applicationName: 'SARANG AD MAKER', applicationVersion: '0.1.0'), icon: const Icon(Icons.info_outline))],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [navy, Color(0xFF263D63)]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('तुमच्या प्रॉडक्टची जाहिरात आता एका क्लिकवर!', style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('फोटो अपलोड करा • माहिती भरा • AI जाहिरात तयार करा', style: TextStyle(color: gold)),
              const SizedBox(height: 12),
              Text(AppConfig.shopName, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              Text(AppConfig.shopPhone, style: const TextStyle(color: Colors.white70)),
            ]),
          ),
          const SizedBox(height: 18),
          const Text('१. प्रॉडक्टचा फोटो', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => choosePhoto(ImageSource.camera), icon: const Icon(Icons.camera_alt), label: const Text('कॅमेरा'))),
            const SizedBox(width: 10),
            Expanded(child: OutlinedButton.icon(onPressed: busy ? null : () => choosePhoto(ImageSource.gallery), icon: const Icon(Icons.photo_library), label: const Text('गॅलरी'))),
          ]),
          if (photo != null) ...[
            const SizedBox(height: 10),
            ClipRRect(borderRadius: BorderRadius.circular(16), child: Image.file(File(photo!.path), height: 210, fit: BoxFit.contain)),
          ],
          const SizedBox(height: 18),
          const Text('२. प्रॉडक्टची माहिती', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          TextField(controller: nameController, decoration: const InputDecoration(labelText: 'प्रॉडक्टचे नाव *', border: OutlineInputBorder(), hintText: 'उदा. Safety Helmet')),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: category,
            isExpanded: true,
            decoration: const InputDecoration(labelText: 'कॅटेगरी', border: OutlineInputBorder()),
            items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
            onChanged: busy ? null : (v) => setState(() => category = v ?? category),
          ),
          const SizedBox(height: 10),
          TextField(controller: brandController, decoration: const InputDecoration(labelText: 'ब्रँड (ऐच्छिक)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: sizeController, decoration: const InputDecoration(labelText: 'साईज / व्हेरिएंट (ऐच्छिक)', border: OutlineInputBorder())),
          const SizedBox(height: 10),
          TextField(controller: taglineController, maxLines: 2, decoration: const InputDecoration(labelText: 'मराठी जाहिरात ओळ', border: OutlineInputBorder())),
          const SizedBox(height: 18),
          const Text('३. AI जाहिरात तयार करा', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 10),
          ElevatedButton.icon(
            onPressed: busy ? null : createAdvertisement,
            icon: busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white)) : const Icon(Icons.auto_awesome),
            label: Text(busy ? 'AI जाहिरात तयार होत आहे...' : 'AI Poster + Animated GIF तयार करा'),
          ),
          if (busy) const Padding(
            padding: EdgeInsets.all(16),
            child: Text('AI प्रक्रिया पूर्ण होण्यासाठी थोडा वेळ लागू शकतो. App बंद करू नका.', textAlign: TextAlign.center),
          ),
          if (error != null) ...[
            const SizedBox(height: 12),
            Text(error!, style: const TextStyle(color: Colors.red, fontWeight: FontWeight.w600)),
          ],
          if (posterUrl != null || gifUrl != null) ...[
            const SizedBox(height: 20),
            const Text('तुमची जाहिरात तयार झाली!', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green)),
            if (posterUrl != null) ...[
              const SizedBox(height: 10),
              const Text('Poster'),
              Image.network(posterUrl!, errorBuilder: (_, __, ___) => const Text('Poster preview लोड झाले नाही.')),
              OutlinedButton.icon(onPressed: () => shareUrl(posterUrl, 'poster'), icon: const Icon(Icons.share), label: const Text('Poster Share करा')),
            ],
            if (gifUrl != null)
              ElevatedButton.icon(onPressed: () => shareUrl(gifUrl, 'gif'), icon: const Icon(Icons.gif_box), label: const Text('Animated GIF WhatsApp वर Share करा')),
          ],
          const SizedBox(height: 20),
          const Divider(),
          const Text('दुकानाचा पत्ता', style: TextStyle(fontWeight: FontWeight.bold)),
          Text(AppConfig.shopAddress),
          const Text('संपर्क: 7038080722'),
        ],
      ),
    );
  }
}
