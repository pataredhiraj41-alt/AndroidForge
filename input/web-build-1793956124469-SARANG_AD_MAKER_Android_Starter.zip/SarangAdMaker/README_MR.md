# SARANG AD MAKER – Android MVP Starter

हा पहिला runnable starter आहे: Flutter Android app + FastAPI backend + PostgreSQL-ready database + AI poster generation + animated GIF export.

## सध्याच्या MVP मध्ये
- मराठी UI
- SARANG ENTERPRISES चे default दुकान तपशील
- Product photo upload
- Product name, category, brand, size आणि Marathi tagline
- Backend मध्ये product record save
- OpenAI Images API वापरून uploaded photo reference वर AI poster edit
- पोस्टरवर shop address/contact footer programmatically लावण्याची जागा
- Poster preview आणि GIF तयार करणे
- Android share sheet मधून WhatsApp/इतर apps वर share

## महत्त्वाचे
- OpenAI API key backend `.env` मध्येच ठेवा. Flutter app मध्ये कधीही API key ठेवू नका.
- AI image generation साठी OpenAI API account, billing आणि तुमच्या organization ला उपलब्ध image model access आवश्यक आहे. API खर्च वेगळा असेल.
- AI poster मध्ये product चे तपशील कधी कधी बदलू शकतात. ग्राहकांना पाठवण्यापूर्वी preview तपासा.
- पहिल्या आवृत्तीत local backend वापरतो. Public hosting/HTTPS नंतर configure करावे.
- Marathi text rendering साठी Docker image मध्ये Noto Devanagari font install केलेला आहे.

## 1. Backend चालवा (Windows PowerShell)
```powershell
cd backend
copy .env.example .env
# .env मध्ये OPENAI_API_KEY भरा
docker compose up --build
```
Backend: `http://localhost:8000`
API docs: `http://localhost:8000/docs`

Docker नसेल तर:
```powershell
cd backend
py -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
copy .env.example .env
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```
Local Python mode साठी PostgreSQL चालू असणे आवश्यक; किंवा `DATABASE_URL` SQLite वर बदला:
`DATABASE_URL=sqlite:///./sarang.db`

## 2. Flutter Android app
Flutter source folder `mobile` आहे. प्रथम Flutter ला पूर्ण Android Gradle scaffolding तयार करू द्या:
```powershell
cd mobile
flutter create --platforms=android --org com.sarang.admaker .
flutter pub get
```
`android/app/src/main/AndroidManifest.xml` मध्ये `ANDROID_MANIFEST_SNIPPET.xml` मधील INTERNET permission जोडा. Local development साठी `<application>` tag मध्ये `android:usesCleartextTraffic="true"` जोडा. Production HTTPS deploy झाल्यावर cleartext traffic बंद करा.

Emulator वापरत असल्यास default API URL `http://10.0.2.2:8000` आहे.
खऱ्या Android फोनवर backend PC वर चालत असल्यास `lib/config.dart` मधील `apiBaseUrl` मध्ये PC चा LAN IP द्या. उदाहरण:
`http://192.168.1.10:8000`
फोन आणि PC एकाच Wi-Fi वर असावेत; Windows Firewall मध्ये TCP 8000 allow करा.

```powershell
flutter run
```

## 3. Android SDK
Android Studio install करा, SDK Manager मधून Android SDK Platform आणि Build Tools install करा, नंतर:
```powershell
flutter doctor
flutter doctor --android-licenses
```

## 4. पुढील production टप्पे
1. Secure admin login आणि user roles
2. Product Master CRUD, brand/size/stock management
3. Category-wise reusable Marathi ad templates
4. Cloud object storage आणि hosted PostgreSQL
5. AI prompt refinement, generation queue, retry/cost tracking
6. Logo upload, custom fonts, watermark controls
7. Store history, duplicate ads, campaign scheduler
8. Play Store release signing and privacy policy

## दुकानाचे default तपशील
SARANG ENTERPRISES – HARDWARE & GENERAL TRADERS  
Gala No. 20, MIDC Centre Complex, Shingve Tukai, Ahmednagar  
7038080722

हे source code starter आहे; अजून production deployment, API key setup आणि Android device testing करणे आवश्यक आहे.
