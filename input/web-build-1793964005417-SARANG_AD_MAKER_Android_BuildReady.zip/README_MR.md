# SARANG AD MAKER – Android Build Package

## AndroidForge साठी
ही ZIP Flutter project च्या root मधून तयार केली आहे. ZIP उघडल्यावर लगेच `pubspec.yaml`, `lib/` आणि `android/` दिसले पाहिजेत. `mobile/` नावाचा अतिरिक्त outer Flutter folder नाही.

1. AndroidForge Web UI उघडा.
2. GitHub connection आधीच Save केलेले असल्यास पुन्हा Token टाकू नका.
3. ही ZIP Upload करा.
4. Target: Android (APK); Build variant: auto किंवा debug निवडा.
5. Build सुरू करा. Failed झाल्यास `AndroidForge-logs` artifact डाउनलोड करा.

## महत्त्वाच्या मर्यादा
- या पॅकेजमध्ये Android Gradle project configuration दिले आहे; AndroidForge/Cloud runner वर प्रत्यक्ष APK Build होणे आवश्यक आहे. या तयार करण्याच्या वातावरणात Flutter SDK/Android SDK उपलब्ध नसल्यामुळे प्रत्यक्ष APK compile किंवा device install test करता आलेला नाही.
- App ला AI जाहिरात तयार करण्यासाठी चालू HTTPS Backend URL आवश्यक आहे. `lib/config.dart` मधील `apiBaseUrl` सध्या emulator च्या local URL वर आहे; Cloud/production server URL नसेल तर फोटो upload/AI generation चालणार नाही.
- Backend साठी `.env` मध्ये `OPENAI_API_KEY`, `PUBLIC_BASE_URL`, आणि production database settings भरा. API key Android app किंवा GitHub ZIP मध्ये ठेवू नका.
- OpenAI image API वापरासाठी स्वतंत्र API account/billing लागू शकते.
- `android/gradle/wrapper/gradle-wrapper.properties` दिले आहे; Cloud runner wrapper उपलब्ध करून देत नसेल तर AndroidForge logs मध्ये wrapper-संबंधित त्रुटी येऊ शकते.

## Flutter project
- `pubspec.yaml` आणि `lib/` project root वर आहेत.
- Android application id: `com.sarang.admaker`
- Minimum Android SDK: 23
- Target/compile SDK: 35
- Java/Kotlin target: 17

## Backend
`backend/` मध्ये FastAPI सेवा आहे. ती स्वतंत्र HTTPS hosting वर deploy करावी लागेल. App मध्ये API key embed करू नये.
